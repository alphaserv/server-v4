--[[
	script/module/nl_mod/nl_spectator.lua
	Hanack (Andreas Schaeffer)
	Created: 24-Okt-2010
	Last Modified: 24-Okt-2010
	License: GPL3

	Funktionen:
		1. Spectator-Status eines Spielers ändern.
		2. Inaktive Spieler in den Spectator schieben

	API-Funktionen:
		fspec(cn, lock)
			Spieler wird im Spectator gefangen. Es koennen beliebige Locks (verwende einen String!)
			verwendet werden.
		funspec(cn, lock)
			Ein Lock für den Spieler mit der entsprechenden CN wird deaktiviert. Sind keine Locks
			mehr vorhanden, kommt der Spieler aus dem Spec frei.
		checkpositions()
			Prueft, ob ein Spieler sich bewegt. Ist dies nicht der Fall, wird er in den Spectator
			geschoben.

	Commands:
		#sp
			Toggles den eigenen Spectator-Status
		#sp <CN>
			Toggles Spectator-Status des Spielers

	Konfigurations-Variablen:
		spectator.autospec_rounds
			Auto-Spectating in autospec_rounds * autospec_intervall seconds
		mapsucks.autospec_interval
			Das Interval, in dem geprüft werden soll

	Laufzeit-Variablen:
		spectator.game.last_pos
			Es werden die letzten Positionen der Spieler gemerkt.

]]



--[[
		API
]]

spectator = {}
spectator.autospec_rounds = 8
spectator.autospec_interval = 10
spectator.game = {}
spectator.game.last_pos = {}

function spectator.checkpositions()
	for ci in server.gclients() do
		cn = ci.cn
		if server.player_status(cn) ~= "spectator" and server.paused ~= 1 and server.timeleft > 0 then
			if not spectator.game.last_pos[cn] then spectator.game.last_pos[cn] = {} end
			x, y, z = server.player_pos(cn)
			if x .. y .. z == spectator.game.last_pos[cn][1] then
				local time_inactive = spectator.game.last_pos[cn][2]*spectator.autospec_interval
				if spectator.game.last_pos[cn][2] >= spectator.autospec_rounds then
					if spectator.game.last_pos[cn][3] ~= 1 then
						server.spec(cn)
						messages.error(cn, {cn}, "SPECTATOR", server.player_displayname(cn) .. " has been put to spectators because of inactivity (" .. time_inactive .. " seconds)")
						spectator.game.last_pos[cn] = nil
					end
				else
					if spectator.game.last_pos[cn][2] >= spectator.autospec_rounds-1 then
						messages.warning(cn, {cn}, "SPECTATOR", server.player_displayname(cn) .. " has been " .. time_inactive .. " seconds inactive. You will be spec'ed shortly because of inactivity!")
					end
					spectator.game.last_pos[cn][2] = spectator.game.last_pos[cn][2] + 1
				end
			else
				spectator.game.last_pos[cn][1] = x .. y .. z
				spectator.game.last_pos[cn][2] = 1
			end
		end
	end
end


function spectator.fspec(cn, lock)
	--irc_say("FSPEC: "..lock)
	local locks = utils.table_copy(nl.getPlayer(cn, "fspec"))
	locks[lock] = true
	nl.updatePlayer(cn, "fspec", locks, "set")
	server.spec(cn)
	messages.debug(-1, players.admins(), "SPECTATOR", server.player_displayname(cn).." has a new spectator lock: "..lock)
end

function spectator.funspec(cn, lock)
	--irc_say("FUNSPEC "..lock)
	local locks = utils.table_copy(nl.getPlayer(cn, "fspec"))
	locks[lock] = nil
	nl.updatePlayer(cn, "fspec", locks, "set")
	if utils.table_size(locks) == 0 then
		server.unspec(cn)
		messages.debug(-1, players.admins(), "SPECTATOR", server.player_displayname(cn).." can now left spectator because lock "..lock.." was disabled")
	else
		messages.debug(-1, players.admins(), "SPECTATOR", server.player_displayname(cn).." is still locked in spectator because of "..spectator.get_lock_reasons(cn))
	end
end

function spectator.is_locked(cn)
	local locks = nl.getPlayer(cn, "fspec")
	if utils.table_size(locks) == 0 then
		messages.debug(-1, players.admins(), "SPECTATOR", server.player_displayname(cn).." has no locks")
		return false
	else
		messages.debug(-1, players.admins(), "SPECTATOR", server.player_displayname(cn).." is locked because: "..spectator.get_lock_reasons(cn))
		return true
	end
end

function spectator.get_lock_reasons(cn)
	local locks = nl.getPlayer(cn, "fspec")
	local l = {}
	for k,v in pairs(locks) do
		table.insert(l, k)
	end
	return table.concat(l, ", ")
end





--[[
		COMMANDS
]]

function server.playercmd_spectator(cn, targetCN)
	if targetCN then
		if not hasaccess(cn, putspec_access) then return end
		if not server.valid_cn(targetCN) then
			messages.error(cn, {cn}, "SPECTATOR", "There is no player with CN " .. targetCN)
			return
		end
		if server.player_status_code(targetCN) == server.SPECTATOR then
			server.unspec(targetCN)
			messages.warning(cn, players.admins(), "SPECTATOR", server.player_displayname(cn) .. " unspeced " .. server.player_displayname(targetCN))
			if spectator.is_locked(targetCN) then
				messages.warning(cn, {cn}, "SPECTATOR", "Caution: You have unlocked player " .. server.player_displayname(targetCN) .. " which was locked into spectator because of " .. spectator.get_lock_reasons(targetCN))
			end
		else
			server.spec(targetCN)
			messages.warning(cn, players.admins(), "SPECTATOR", server.player_displayname(cn) .. " speced " .. server.player_displayname(targetCN))
		end
	else
		if server.player_status_code(cn) == server.SPECTATOR then
			if not spectator.is_locked(cn) then
				server.unspec(cn)
			else
				messages.error(cn, {cn}, "SPECTATOR", "You cannot leave spectator because of: "..spectator.get_lock_reasons(cn))
			end
		else
			server.spec(cn)
		end
	end
end
server.playercmd_sp = server.playercmd_spectator

function server.playercmd_specall(cn)
	if not hasaccess(cn, spec_access) then return end
	server.specall()
end

function server.playercmd_unspecall(cn)
	if not hasaccess(cn, spec_access) then return end
	-- server.unspecall()
	for _, tcn in pairs(players.spectators()) do
		if not spectator.is_locked(tcn) then
			server.unspec(tcn)
		end
	end
end



--[[
		EVENTS
]]

server.interval(spectator.autospec_interval*1000, spectator.checkpositions)

server.event_handler("request_spectator", function(cn, ocn, val)
	if spectator.is_locked(cn) then
		messages.error(cn, {cn}, "SPECTATOR", "You cannot leave spectator because of: "..spectator.get_lock_reasons(cn))
		return -1
	end
end)

server.event_handler("connect", function(cn) spectator.game.last_pos[cn] = nil end)
server.event_handler("disconnect", function(cn) spectator.game.last_pos[cn] = nil end)
server.event_handler("spectator", function(cn)spectator.game.last_pos[cn] = nil end)
server.event_handler("mapchange", function() spectator.game.last_pos = {} end)

server.event_handler("takeflag", function(cn)
	if not spectator.game.last_pos[cn] then spectator.game.last_pos[cn] = {} end
	spectator.game.last_pos[cn][3] = 1
end)

server.event_handler("scoreflag", function(cn) 
	if not spectator.game.last_pos[cn] then spectator.game.last_pos[cn] = {} end
	spectator.game.last_pos[cn][3] = 0
end)

server.event_handler("dropflag", function(cn) 
	if not spectator.game.last_pos[cn] then spectator.game.last_pos[cn] = {} end
	spectator.game.last_pos[cn][3] = 0
end)
