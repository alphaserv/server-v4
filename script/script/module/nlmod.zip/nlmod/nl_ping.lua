--[[
	script/module/nl_mod/nl_ping.lua
	Hanack (Andreas Schaeffer)
	Created: 27-Sep-2010
	Last Modified: 12-Nov-2010
	License: GPL3

	Funktionen:
		* Überprüft den Ping jedes Spielers
		* Wenn der Ping über eine bestimmte Grenze kommt, werden Maluspunkte vergeben
		* Wenn der Ping unter eine bestimmte Grenze kommt, werden Maluspunkte verringert
		* Wenn er genügend Maluspunkte angesammelt hat, wird er gespeced
		* Wenn er einen konstant guten Ping hat, wird er wieder unspeced
	

	API-Methoden:
		ping.check()
			Prueft den Ping aller Spieler

	Konfigurations-Variablen:

	Laufzeit-Variablen:


]]



--[[
		API
]]

ping = {}
ping.ping = { 250, 450 }
ping.lag = { 60, 80 }
ping.malusadd = { 1, 5 }
ping.malusmax = { 20, 40 }
ping.malus = {}
ping.speced = {}
ping.level = {}


function ping.check()
	for i,cn in pairs(players.all()) do
		if ping.malus[cn] == nil then
			ping.malus[cn] = 0
		end
		if ping.level[cn] == nil then
			ping.level[cn] = 0
		end
		-- DEBUG:
		messages.debug(-1, players.admins(), "PING", "cn: " .. cn .. " lv: " .. ping.level[cn] .. " pt: " .. ping.malus[cn] .. " ping: " .. server.player_ping(cn) .. " lag: " .. server.player_lag(cn) .. " (" .. server.player_displayname(cn) .. ")")
	
		-- maluspunkte sammeln

		if ping.malus[cn] >= ping.malusadd[1] and server.player_ping(cn) < ping.ping[1] then
			ping.malus[cn] = ping.malus[cn] - ping.malusadd[1]
		elseif server.player_ping(cn) >= ping.ping[1] and server.player_lag(cn) >= ping.lag[1] and server.player_ping(cn) < ping.ping[2] and server.player_status_code(cn) ~= server.SPECTATOR then
			ping.malus[cn] = ping.malus[cn] + ping.malusadd[1]
		elseif server.player_ping(cn) >= ping.ping[2] and server.player_status_code(cn) ~= server.SPECTATOR then
			ping.malus[cn] = ping.malus[cn] + ping.malusadd[2]
		end
		
		-- maluspunkte auswerten / Zustandsänderungen
		if ping.malus[cn] < ping.malusmax[1] and ping.level[cn] > 0 then
			ping.level[cn] = 0
			spectator.funspec(cn, "PING")
			messages.info(cn, {cn}, "PING", "Thank you for fixing your ping!")
			messages.irc("PING", string.format("%s have fixed his ping!", server.player_displayname(cn)))
		elseif ping.malus[cn] >= ping.malusmax[1] and ping.level[cn] == 0 then
			ping.level[cn] = 1
			messages.warning(cn, {cn}, "PING", "WARNING: Please fix your ping NOW or you will be spec'ed!")
		elseif ping.malus[cn] >= ping.malusmax[2] and ping.level[cn] == 1 then
			ping.level[cn] = 2
			spectator.fspec(cn, "PING")
			messages.error(cn, {cn}, "PING", "You have been spec'ed because your ping is constantly too high!")
			messages.irc("PING", string.format("%s have been spec'ed because his ping is constantly too high!", server.player_displayname(cn)))
		end
		
    end
end



--[[
		EVENTS
]]

server.event_handler("connect", function(cn)
	ping.speced[cn] = 0
	ping.malus[cn] = 0
	ping.level[cn] = 0
end)

server.event_handler("disconnect", function(cn)
	ping.speced[cn] = 0
	ping.malus[cn] = 0
	ping.level[cn] = 0
end)

server.interval(500, ping.check)
