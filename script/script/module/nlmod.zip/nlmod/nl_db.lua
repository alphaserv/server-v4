--[[
	script/module/nl_mod/nl_db.lua
	Hanack (Andreas Schaeffer)
	Created: 23-Okt-2010
	Last Modified: 23-Okt-2010
	License: GPL3

	Funktionen:
		Zugriff auf die Datenbank
	

	API-Methoden:
		db.insert(db_table, data)
			Fügt einen Datensatz in die Tabelle db_table ein. Die Daten liegen in der Variablen
			data vor, wobei Key und Value berücksichtigt werden.
			z.B. wird in die Spalte id der Wert 20 gespeichert: data['id'] = 20
		db.select(db_table, keys, where)
		db.select_and(db_table, keys, where)
		db.select_or(db_table, keys, where)

	Konfigurations-Variablen:
		db.templates
			SQL Templates

	Laufzeit-Variablen:
		db.xyz
			xyz


]]



require "luasql_mysql"

--[[
		API
]]

db = {}
db.templates = {}
db.templates.select = [[SELECT %s FROM %s WHERE %s]]
db.templates.insert = [[INSERT INTO %s (%s) VALUES (%s)]]
db.templates.update = [[UPDATE %s SET %s WHERE %s]]

function db.insert(db_table, data)
	local keys = {}
	local values = {}
	for key, value in pairs(data) do
		table.insert(keys, key)
		if utils.is_numeric(value) then 
			table.insert(values, value)
		else
			table.insert(values, string.format("'%s'", value))
		end
	end
	local keys_string = table.concat(keys, ", ")
	local values_string = table.concat(values, ", ")
	local sql = string.format(db.templates.insert, db_table, keys_string, values_string)
	local env = assert (luasql.mysql())
	local con = assert (env:connect(server.stats_mysql_database, server.stats_mysql_username, server.stats_mysql_password, server.stats_mysql_hostname, server.stats_mysql_port))
	local cur = assert (con:execute(sql))
	if not con:close() then server.log_error("con:close failed in nl_db") end
	if not env:close() then server.log_error("env:close failed in nl_db") end
end

function db.update(db_table, data, where)
	local sql = string.format(db.templates.update, db_table, db.get_fields_string(data), where)
	local env = assert (luasql.mysql())
	local con = assert (env:connect(server.stats_mysql_database, server.stats_mysql_username, server.stats_mysql_password, server.stats_mysql_hostname, server.stats_mysql_port))
	local cur = assert (con:execute(sql))
	if not con:close() then server.log_error("con:close failed in nl_db") end
	if not env:close() then server.log_error("env:close failed in nl_db") end
end

function db.insert_or_update(db_table, data, where)
	local data2 = db.select(db_table, {"*"}, where)
	if #data2 > 0 then
		db.update(db_table, data, where)
	else
		db.insert(db_table, data)
	end
end

function db.select_and(db_table, keys, where)
	return db.select(db_table, keys, db.get_where(where, " AND "))
end

function db.select_or(db_table, keys, where)
	return db.select(db_table, keys, db.get_where(where, " OR "))
end

function db.select(db_table, keys, where)
	local data = {}
	local keys_string = table.concat(keys, ", ")
	local sql = string.format(db.templates.select, keys_string, db_table, where)
	-- server.msg(sql)
	local env = assert (luasql.mysql())
	local con = assert (env:connect(server.stats_mysql_database, server.stats_mysql_username, server.stats_mysql_password, server.stats_mysql_hostname, server.stats_mysql_port))
	local cur = assert (con:execute(sql))
	if cur:numrows() > 0 then
		local row = cur:fetch ({}, "a")
		while row do
			-- server.msg("FO:"..utils.table_tostring(row))
			table.insert(data, utils.table_copy(row))
			row = cur:fetch (row, "a")
			-- server.msg("FN:"..utils.table_tostring(row))
			-- server.msg("DATA:"..utils.table_tostring(data))
		end
	end
	if not con:close() then server.log_error("con:close failed in nl_db") end
	if not env:close() then server.log_error("env:close failed in nl_db") end
	-- server.msg(utils.table_tostring(data))
	return data
end

function db.get_where(where, op)
	local where_values = {}
	for key, value in pairs(where) do
		if utils.is_numeric(value) then 
			table.insert(where_values, string.format("%s = %i", key, value))
		else
			table.insert(where_values, string.format("%s = '%s'", key, value))
		end
	end
	return table.concat(where_values, op)
end

function db.get_fields_string(data)
	local fields_values = {}
	for key, value in pairs(data) do
		if utils.is_numeric(value) then 
			table.insert(fields_values, string.format("%s = %i", key, value))
		else
			table.insert(fields_values, string.format("%s = '%s'", key, value))
		end
	end
	return table.concat(fields_values, ", ")
end
