dofile("script/module/nlmod/tools.lua")

dofile("script/module/nlmod/loadscript.lua")

promod.read_script("script/module/nlmod/msg.lua", "message functions")
promod.read_script("script/module/nlmod/descmsg.lua", "descmessage functions")

promod.read_script("script/module/nlmod/fake_admin.lua", "fake admin system")

promod.read_script("script/module/nlmod/_access.lua", "access functions")
promod.read_script("script/module/nlmod/_access_list.lua", "access list")
promod.read_script("script/module/nlmod/localxstatsaccess.lua", "local xstats access")

promod.read_script("script/module/nlmod/setmaster.lua", "setmaster handling")
promod.read_script("script/module/nlmod/bans.lua", "ban system")
promod.read_script("script/module/nlmod/invite.lua", "invite system")
promod.read_script("script/module/nlmod/kick_protection.lua", "kick protection")
promod.read_script("script/module/nlmod/kickban.lua", "kick system")
promod.read_script("script/module/nlmod/authconnecting.lua", "authconnect system")

promod.read_script("script/module/nlmod/connecting.lua", "connect system")

promod.read_script("script/module/nlmod/command.lua", "command system")
promod.read_script("script/module/nlmod/_command_access.lua", "command access list")
promod.read_script("script/module/nlmod/_bindings.lua", "command bindings")

promod.read_script("script/module/nlmod/_actions.lua", "actions control system")

promod.read_script("script/module/nlmod/recordgames.lua", "recording system")
promod.read_script("script/module/nlmod/flagrun.lua", "flagrun system")
promod.read_script("script/module/nlmod/best_stats.lua", "best stats system")
-- promod.read_script("script/module/nlmod/teamkills.lua", "teamkill control system")
-- promod.read_script("script/module/nlmod/banner.lua", "banner system")

promod.read_script("script/module/nlmod/mastermode.lua", "mastermode system")

promod.read_script("script/module/nlmod/restart_on_empty.lua", "restart system")

-- promod.read_script("script/module/nlmod/camping.lua", "camping control system")

-- promod.read_script("script/module/nlmod/teambalance.lua", "teambalance system")

promod.read_script("script/module/nlmod/pvar.lua", "pvar system")
promod.read_script("script/module/nlmod/aplayers.lua", "aplayers fix")

-- promod.read_script("script/module/nlmod/gamemode.lua", "gamemode functions")
--promod.read_script("script/module/nlmod/maprotation.lua", "maprotation system")

promod.read_script("script/module/nlmod/sendinitclient.lua", "sendinitclient control system")

-- promod.read_script("script/module/nlmod/shuffle.lua", "shuffle system")

--promod.read_script("script/module/nlmod/inactivity.lua", "inactivity control system")

-- promod.read_script("script/module/nlmod/speed.lua", "speed control system")

promod.read_script("script/module/nlmod/mapcrc.lua", "mapcrc check system")

promod.read_script("script/module/nlmod/no_teamkills.lua", "teamkill protection system")
promod.read_script("script/module/nlmod/no_spawnkill.lua", "spawnkill protection system")

promod.read_script("script/module/nlmod/spawnassistant.lua", "spawn assistant")


promod.read_script("script/module/nlmod/nl_bot.lua", "nl bot")

server.botlimit = 0

-- generic
promod.read_script("script/module/nlmod/nl_db.lua", "Datenbankzugriffe")
promod.read_script("script/module/nlmod/nl_reconnect.lua", "Reconnect Framework")
promod.read_script("script/module/nlmod/nl_core.lua", "nl Core")
promod.read_script("script/module/nlmod/nl_utils.lua", "Allgemeine Helferfunktionen")
promod.read_script("script/module/nlmod/nl_players.lua", "Funktionen fuer Operationen auf Spielerlisten")
promod.read_script("script/module/nlmod/nl_messages.lua", "Nooblounge Message System")
promod.read_script("script/module/nlmod/nl_extractcommand.lua", "nooblounge extract commands from console text messages")
promod.read_script("script/module/nlmod/nl_cubes2c.lua", "cubes2c system nooblounge mod")
promod.read_script("script/module/nlmod/nl_services.lua", "nooblounge masterserver services framework")

promod.read_script("script/module/nlmod/nl_spectator.lua", "spectator control")

promod.read_script("script/module/nlmod/nl_protect.lua", "nl nameprotection")

--promod.read_script("script/module/nlmod/nl_stats.lua", "nl stats")

-- map rotation, intermission, veto, mapbattles ...
promod.read_script("script/module/nlmod/nl_maprotation.lua", "nooblounge map rotation system")
promod.read_script("script/module/nlmod/nl_mapbattle.lua", "intermission mode: mapbattle")
promod.read_script("script/module/nlmod/nl_veto.lua", "intermission mode: vetos")
promod.read_script("script/module/nlmod/nl_mapsucks.lua", "map sucks functionality")
promod.read_script("script/module/nlmod/nl_announce.lua", "announce system")

-- balance, teamfunctions ...
promod.read_script("script/module/nlmod/nl_balance.lua", "nooblounge team balance")
promod.read_script("script/module/nlmod/nl_shuffle.lua", "nooblounge team shuffle")

-- badphrases, cheaters, modified maps, ping
promod.read_script("script/module/nlmod/nl_cheater.lua", "cheater protection")
promod.read_script("script/module/nlmod/nl_modifiedmap.lua", "modified map protection")
promod.read_script("script/module/nlmod/nl_badphrase.lua", "bad phrases protection")
promod.read_script("script/module/nlmod/nl_speedhack.lua", "speedhack protection")
promod.read_script("script/module/nlmod/nl_camping.lua", "camping protection")
promod.read_script("script/module/nlmod/nl_ping.lua", "ping protection")
promod.read_script("script/module/nlmod/nl_teamkiller.lua", "teamkiller protection")
-- chainsaw hack protection

-- admin and player commands
promod.read_script("script/module/nlmod/nl_warn.lua", "warnings")
promod.read_script("script/module/nlmod/nl_changeteam.lua", "changeteam control")
promod.read_script("script/module/nlmod/nl_silence.lua", "silence control")
promod.read_script("script/module/nlmod/nl_who.lua", "who is playing")
promod.read_script("script/module/nlmod/nl_god.lua", "admin only")
promod.read_script("script/module/nlmod/nl_access.lua", "accesscommands")

-- nooblounge services framework
promod.read_script("script/module/nlservices/repository.lua", "services repository")
promod.read_script("script/module/nlservices/servers.lua", "servers")
promod.read_script("script/module/nlservices/date.lua", "date")
promod.read_script("script/module/nlservices/mapbattle.lua", "mapbattle")
promod.read_script("script/module/nlservices/basicprofile.lua", "basicprofile")

