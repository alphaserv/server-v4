auth.directory.domain{
    id = "is:admin",
    server = "LOCAL"
}

auth.directory.domain{
    id = "cubelove:admin",
    server = "LOCAL"
}

auth.directory.user{
    domain = "cubelove:admin",
    id = "TheLove",
    public_key = "-79ffcf3514c1a64eb554cceba225a0b3022b3534d05dd431"
}
auth.directory.user{
    domain = "cubelove:admin",
    id = "LoveForEver",
    public_key = "+bcc6996ef2a321115a7651f97eb5376c8d4dfebc7adfd700"
}

auth.directory.user{
    domain = "is:admin",
    id = "X35",
    public_key = "-16b3f118920c5b004817fbfebedf560c309e59918c89aaee"
}
auth.directory.user{
    domain = "is:admin",
    id = "Ironman",
    public_key = "-2b8dbdbef18a82597233f71e0369c65b85ba33e5a6504487"
}
auth.directory.user{
    domain = "is:admin",
    id = "bader",
    public_key = "+3d3de0870cd084f281f3b398eb93d67775bc8971c1179236"
}
auth.directory.user{
    domain = "is:admin",
    id = "gidgey",
    public_key = "-59633867c371f7e1a5908f302e5f620a5df8da3d8401a35d"
}
auth.directory.user{
    domain = "is:admin",
    id = "sapik",
    public_key = "-9c66f6402f69d2c8d568a64bfb7cf0a168c118458e480b1c"
}
auth.directory.user{
    domain = "is:admin",
    id = "cereal",
    public_key = "+8fc30486a039d4bb8b30dde697e82589ecb955a13cd4422e"
}

auth.directory.user{
   domain = "is:admin",
   id = "Hankus",
   public_key = "+84dacd59b461bcd3ee5c74bf59d0c5f2483c8410e4f955ef"
}
