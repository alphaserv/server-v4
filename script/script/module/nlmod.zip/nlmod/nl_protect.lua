--[[
	script/module/nl_mod/nl_protect.lua
	Derk Haendel
	20-Sep-2010
	License: GPL3

	function nl.check_player_status(cn, pass, method)
	  cn=clientnumber, pass=Spielerpasswort, method=("md5"/"sauer")
		Pr�ft den Spielerstatus und schreibt ihn in die Spielervariabe nl_status
	
	function nl.set_player_status(cn)
		Gibt oder entzieht dem Spieler Rechte gem. der Spielervariablen nl_status
	
	function nl.login(cn, arg1, arg2)
		Stellt den #login-Befehl zur Verf�gung
	
]]

require "luasql_mysql"
require "md5"
require "geoip"

function nl.check_player_status(cn, pass, method)

	local servername
	local env
	local con
	local row
	local sql
	local anz
	local aktname = string.upper(server.player_name(cn))
	local basename
	local basepass
	local aktpass = "342765ewhwrzt6645"
	local cancel = false
	
	if not method then method = "md5" end
	
	if pass == "" then pass = "x1x4x7x9x0" end
	
	if method == "md5" then
		aktpass = md5.sumhexa(pass)
	else
		aktpass = pass
	end
	
	env = assert (luasql.mysql())
	con = assert (env:connect(server.stats_mysql_database, server.stats_mysql_username, server.stats_mysql_password, server.stats_mysql_hostname, server.stats_mysql_port));
	
	sql = "SELECT * FROM user WHERE CHAR_LENGTH(pwd_clear) > 0"
	cur = assert (con:execute(sql))
	row = cur:fetch ({}, "a")

	nl.updatePlayer(cn, "nl_status", "none", "set")
	nl.updatePlayer(cn, "statsname", tostring(server.player_name(cn)), "set")

	while row do
		basename = string.upper(row.nickname)
		clantag = string.upper(row.clantag)
		activated = tostring(row.activated)
		if (aktname == basename) or (aktname == clantag .. basename) or (aktname == basename .. clantag) then
			if (activated == '1') then
				nl.updatePlayer(cn, "nl_status", "protected", "set")
				if method == "md5" then
					basepass = row.password				else
					basepass = server.hashpassword(cn, row.pwd_clear)
				end
				if tostring(row.adminlevel) == "9" then
					nl.updatePlayer(cn, "nl_status", "banned", "set")
					cancel = true
				end
				if tostring(row.adminlevel) == "8" then
					nl.updatePlayer(cn, "nl_status", "blocked", "set")
					cancel = true
				end
				
				if not cancel then
					if string.match(aktpass, basepass) then
						nl.updatePlayer(cn, "nl_status", "user", "set")
						nl.updatePlayer(cn, "nl_greet", tostring(row.greet), "set")
						nl.updatePlayer(cn, "statsname", tostring(row.nickname), "set")
						if tostring(row.adminlevel) == "1" then
							nl.updatePlayer(cn, "nl_status", "admin", "set")
						end
					end
				end

			else
				nl.updatePlayer(cn, "nl_status", "pending", "set")
			end
		end
	  row = cur:fetch (row, "a")
	end

	if not cur:close() then server.log_error("cur:close failed in nl.checkname") end
	if not con:close() then server.log_error("con:close failed in nl.checkname") end
	if not env:close() then server.log_error("env:close failed in nl.checkname") end
end

function nl.set_player_status(cn)
	local player_id = server.player_sessionid(cn)
	local player = nl_players[player_id]
	
	--irc_say(string.format("setPlayerStatus(cn=%i) %s-Status=%s", cn, player.name, player.nl_status))

	if player.nl_status == "none" then
		if server.player_priv_code(cn) > 0 then server.unsetpriv(cn) end
		if server.is_muted(cn) then server.unmute(cn) end
		if server.player_status_code(cn) == server.SPECTATOR then spectator.funspec(cn, "LOGIN") end
		messages.error(-1, {cn}, "LOGIN", "Please register your name here: www.nooblounge.net")
		-- server.player_msg(cn,red("Please register your name here: www.nooblounge.net"))
	elseif player.nl_status == "pending" then
		if server.player_priv_code(cn) > 0 then server.unsetpriv(cn) end
		spectator.fspec(cn, "LOGIN")
		server.mute(cn)
		messages.error(-1, {cn}, "LOGIN", "This name is protected but not activated.")
		messages.error(-1, {cn}, "LOGIN", "If this is your name, check your emails for activation-link.")
		-- server.player_msg(cn,red("This name is protected but not activated."))
		-- server.player_msg(cn,red("If this is your name, check your emails for activation-link."))
	elseif player.nl_status == "protected" then
		if server.player_priv_code(cn) > 0 then server.unsetpriv(cn) end
		spectator.fspec(cn, "LOGIN")
		server.mute(cn)
		messages.error(-1, {cn}, "LOGIN", "You are using a protected name.")
		messages.error(-1, {cn}, "LOGIN", "Please change your name or authenticate with #login.")
		-- server.player_msg(cn,red("You are using a protected name."))
		-- server.player_msg(cn,red("Please change your name or authenticate with #login."))
	elseif player.nl_status == "user" then
		if server.player_priv_code(cn) > 0 then server.unsetpriv(cn) end
		if server.is_muted(cn) then server.unmute(cn) end
		if server.player_status_code(cn) == server.SPECTATOR then spectator.funspec(cn, "LOGIN") end
		nl.set_access(cn, 100)
		server.msg(string.format(blue("%s") .. orange(" is now logged in as ") .. red("registered player."), server.player_displayname(cn)))
		if string.len(tostring(player.nl_greet)) > 0 then
			server.msg(string.format(white("%s says: ") .. green("%s"), player.name, tostring(player.nl_greet)))
		end
	elseif player.nl_status == "admin" then
		if server.is_muted(cn) then server.unmute(cn) end
		if server.player_status_code(cn) == server.SPECTATOR then spectator.funspec(cn, "LOGIN") end
		nl.set_access(cn, 500)
		--server.set_invisible_admin(cn)
		server.msg(string.format(blue("%s") .. orange(" is now logged in as ") .. red("admin."), server.player_displayname(cn)))
		if string.len(tostring(player.nl_greet)) > 0 then
			server.msg(string.format(white("%s says: ") .. green("%s"), player.name, tostring(player.nl_greet)))
		end
	elseif player.nl_status == "blocked" then
		if server.player_priv_code(cn) > 0 then server.unsetpriv(cn) end
		spectator.fspec(cn, "LOGIN")
		server.mute(cn)
		messages.error(-1, {cn}, "LOGIN", "Please change your name. For example type:")
		messages.error(-1, {cn}, "LOGIN", "/name yourname")
		--server.player_msg(cn,red("Please change your name. For example type:"))
		--server.player_msg(cn,red("/name yourname"))
	end

end

function nl.set_access(cn, value)
	server.set_access(cn, value)
	messages.debug(-1, {cn}, "LOGIN", "Your access has been set to ".. value)
	-- server.log(string.format("%s playing as %s(%i) used /setmaster to set access (to %s)", name, server.player_name(cn), cn, tostring(value)))
	-- server.sleep(10, function() xbotlog(user .. " (currently '" .. server.player_name(cn) .. "' (" .. cn .. ")) used /setmaster to set access to " .. value) end)
end

function server.playercmd_login(cn, arg1, arg2)
	local player_id = server.player_sessionid(cn)
	local player = nl_players[player_id]

	if player.nl_status == "user" or player.nl_status == "admin" then
		messages.error(-1, {cn}, "LOGIN", "You are already logged in ...")
		return
	end

	if not arg1 then
		messages.error(-1, {cn}, "LOGIN", "Password is missing")
		return
	end
	if arg2 then
		pass = arg2
	else
		pass = arg1
	end
	
	nl.check_player_status(cn, pass, "md5")
	nl.set_player_status(cn)
end

--[[
function server.playercmd_login(cn)
	if not hasaccess(cn, mute_access) then return end
	mutespecs = true
	server.msg(togglemsg("mutespecs", true))
end
]]

--[[
      EVENT HANDLERS
]]

server.event_handler("rename", function(cn, oldname, name)
	if nl.getPlayer(cn, "slotpass") == "none" then
		nl.check_player_status(cn, "", "md5")
	else
		nl.check_player_status(cn, tostring(nl.getPlayer(cn, "slotpass")), "sauer")
	end
	nl.set_player_status(cn)
	if nl.getPlayer(cn, "nl_status") == "banned" then
		server.kick(cn, 3600, server.player_displayname(cn), "Use of a banned name.")
	end
end)

