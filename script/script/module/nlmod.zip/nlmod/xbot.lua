--	xbot client script by X35

server.log("call 4 xbot")