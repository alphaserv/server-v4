function server.aplayers() return server.gclients() end
