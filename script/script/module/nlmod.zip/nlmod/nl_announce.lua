--[[
	script/module/nl_mod/nl_announce.lua
	Hanack (Andreas Schaeffer)
	Created: 20-Sep-2010
	Last Modified: 24-Okt-2010
	License: GPL3

	Funktionen:
		Spammt alle Spieler mit unnützen Nachrichten zu.

	Commands:
		#announce <TEXT>
			xyz

	API-Methoden:
		announce.xyz()
			xyz

	Konfigurations-Variablen:
		announce.xyz
			xyz
]]



--[[
		API
]]

announce = {}
announce.interval = 45000
announce.current = 0
announce.banners = {}

function announce.next()
	if maprotation.intermission_running == 0 then
		announce.current = announce.current + 1
		local banners = announce.banners
		if announce.current > #banners then
			announce.current = 1
		end
		messages.info(-1, players.all(), banners[announce.current].label, banners[announce.current].text)
		-- server.msg(green("  [ " .. banners[announce.current].label .. " ]  ") .. banners[announce.current].text)
	end
end

function announce.load()
	announce.banners = db.select('nl_announce', { 'label', 'text' }, 'active = 1')
end



--[[
		COMMANDS
]]

function server.playercmd_announce(cn, command, arg, arg2)
	if not hasaccess(cn, admin_access) then return end
	if command == nil then
		return false, "#announce <CMD> [<ARG>]"
	else
		if arg == nil then
			if command == "reload" then
				announce.load()
			end
			if command == "next" then
				announce.next()
			end
			if command == "messages" or command == "list" then
				messages.info(cn, {cn}, "ANNOUNCE", "List of all active messages:")
				for i,banner in pairs(announce.banners) do
					messages.info(cn, {cn}, "ANNOUNCE", "  [ "..banner.label.." ]  "..banner.text)
				end
			end
			if command == "info" then
				messages.info(cn, {cn}, "ANNOUNCE", "announce.interval=" .. announce.interval)
				messages.info(cn, {cn}, "ANNOUNCE", "announce.current=" .. announce.current)
			end
		else
			if command == "new" then
				if arg2 == nil then
					return false, "#announce new <LABEL> <TEXT>"
				end
				db.insert("nl_announce", { label=arg, text=arg2, active=1, frequency=1 })
			end
			if command == "send" then
				messages.info(-1, players.all(), "INFO", arg)
			end
			if command == "interval" then
				announce.interval = arg
				messages.info(cn, {cn}, "ANNOUNCE", "announce.interval=" .. announce.interval)
			end
		end
	end
end



--[[
		EVENTS
]]

server.interval(announce.interval, announce.next)

server.event_handler("started", function()
	server.sleep(1000, function()
		announce.load()
	end)
end)

