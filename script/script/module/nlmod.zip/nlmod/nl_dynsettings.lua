--[[

	Idee: jede Variable, die eine Konfigurationseinstellung ist bzw. sein könnte,
	wird als Variable in der Datenbank gespeichert.

	Man kann so Profile bilden und Konfigurationen einfach laden.

]]