--[[
Balance function
move one player from an team with less players to an team with lesser players.
If only one player difference the skript will not take action.

Author: NuckChorris
Last Modified: 18/Nov/2010
Version: 0.02

returns:
 0 if Balance is performed and some player got a batch.
-1 if No balance is needed teams are balanced.
-2 if No balance performed one player difference.
-3 if No matched player is found.
]]

balance = {}

function nl.balance(cn)
-- if do_balance false no balance required
if nl_game.do_balance == false or server.nl_balance_enabled ~= 1 then

   messages.debug(cn, players.admins(),"BALANCE","No balance required, do_balance = false. Balance ended")
   errorLog("No balance required, do_balance = false. Balance ended\n","Balance")
   return -1
end

local scorecn = 0
local player_id = -1
local teamtype = "good"
local team1 = {}     --contains the index and the cn
local team2 = {}     --contains the index and the cn
local teampw1 = {}   --contains the index and the playerweight
local teampw2 = {}   --contains the index and the playerweight
local wholeall = {0,0}
local plnumbers = {0,0}
local diff12 = 0
local diff21 = 0
local diffCount = 0
local diff = 0 --difference between wholeall[1] and wholeall[2]
local balcn = -1
local secondloop = 0
local endloop = 0

wholeall[1]=0
wholeall[2]=0

--set se random seed again.
--math.randomseed(os.time())

errorLog("Balance is started","Balance")
   --loop to fill the teams variable with both team tables, 
   --and fill the team tables with all available

   team1=server.team_players("good")
   team2=server.team_players("evil")

   for key,tab in pairs(team1) do
      errorLog("Team1 CN= "..tostring(tab),"Balance")
   end
   for key,tab in pairs(team2) do
      errorLog("Team2 CN= "..tostring(tab),"Balance")
   end

   --calculate for both teams the howlall variable from the all
   --variable for each player from the playerweight() function

   --!!!!!On every sort or change on any team-table teamcn-table must also bean changed!!!!!
   teampw1,wholeall[1],plnumbers[1] = balance.filltables(team1)
   teampw2,wholeall[2],plnumbers[2] = balance.filltables(team2)

   --if plnumbers[1] < plnumbers[2] then a teamswitch must be forced
   --the howall[] variables will be compared with each other to find out the best person.

   diff12=wholeall[1]-wholeall[2]   --difference between the skills of team1 and team2
   diff21=wholeall[2]-wholeall[1]   --difference between the skills of team2 and team1
   diffCount=math.abs(plnumbers[1]-plnumbers[2]) --find out the maximal difference of players between the both teams

   --Cancel the function if no balance is needed
   if diffCount == 0 then	
      messages.debug(-1, players.admins(),"BALANCE","No balance required, Teams are balanced. Balance ended")
      errorLog("No balance required, Teams are balanced. Balance ended\n"..tostring(diffCount),"Balance")
      nl_game.do_balance = false
      return -1
   end

   --Sort the team and teampw table
   team1,teampw1=balance.sortPlayers(team1,teampw1)
   team2,teampw2=balance.sortPlayers(team2,teampw2)

   --choose the team with the most players, and calculate the loop times.
   --If the killed player is not in the team with the most player, BALANCE returns -5
   if plnumbers[1] < plnumbers[2] then
      for key,tab in pairs(team1) do
         if tab == cn then
            messages.debug(cn, players.all(), "BALANCE","KILLED Player is in the wrong team")
            return -5
         end
      end
      if plnumbers[2] <=6 then
         endloop =(plnumbers[2]/2)
      elseif plnumbers[2] < 12 then      
         endloop = 4
      else         
         endloop = 5  
      end
   else
      for key,tab in pairs(team2) do
         if tab == cn then
            messages.debug(cn, players.all(), "BALANCE","KILLED Player is in the wrong team")
            return -5
         end
      end     
      if plnumbers[1] <=6 then
         endloop =(plnumbers[1]/2)
      elseif plnumbers[1] < 12 then      
         endloop = 4
      else         
         endloop = 5  
      end
   end
   endloop = math.ceil(endloop)

   --find out the right proceeding for the switch
   --only do balance if there is more then one player difference
   while secondloop <= endloop do
         if diffCount > 1 then
               --choose the right function to balance
               if     plnumbers[1] < plnumbers[2] and diff21 > 0 then
               errorLog("1","Balance_4Function")
               --balance  
                  balcn = balance.bestMatch(team2,teampw2,diff21,balcn)
               elseif plnumbers[1] < plnumbers[2] and diff21 <= 0 then    
               errorLog("2","Balance_4Function")         
               --switch lowest player        
                  balcn = balance.findLowest(team2,teampw2,balcn)
               elseif plnumbers[1] > plnumbers[2] and diff12 > 0 then
               errorLog("3","Balance_4Function")
               --balance
                  balcn = balance.bestMatch(team1,teampw1,diff12,balcn)
               elseif plnumbers[1] > plnumbers[2] and diff12 <= 0 then
               errorLog("4","Balance_4Function")
               --switch lowest player
                  balcn = balance.findLowest(team1,teampw1,balcn)        
               end
               
               errorLog("balcn "..tostring(balcn).." cn "..tostring(cn).." loop "..tostring(secondloop),"Balance")
               -- Only if the given cn is equal to balcn do switch
               if balcn == cn then
                  balance.changeTeam(balcn)
                  secondloop = 2

               messages.debug(-1, players.all(), "BALANCE", "Balance performed.Player balanced")
               errorLog("Balance performed.Player balanced\n","Balance")
               return 0
               else      
                  secondloop = secondloop + 1
                  if secondloop == endloop then
                     messages.debug(-1, players.all(), "BALANCE", "Balance performed. No player balanced, NO MATCH")
                     errorLog("Balance performed. No player balanced, NO MATCH\n","Balance")
                     return -3
                  end
               end
         else
            messages.debug(-1, players.all(), "BALANCE","No balance performed! Team1=Team2")
            errorLog("No balance performed!\n","Balance")
            nl_game.do_balance = false
            return -2
         end
   end
end

--[[ FILLTABLES
returns teamcn, wholeall1,plnumbers1
]]
function balance.filltables(team)
   plnumbers1=0
   plweight=0
   wholeall1=0
   teamcn = {}
   
   for key,playercn in pairs(team) do
      plweight = balance.playerweight(playercn)

      --add a random from plus or minus 0-5%  
        -- plusminus = math.random(0,1)
         --   if plusminus == 0 then
         --      plweight = plweight*(1+math.random(0,5)/100)
         --   else               
         --     plweight = plweight*(1-math.random(0,5)/100)
         --   end

      if plweight ~= (-1) then
         wholeall1=wholeall1+plweight  --Variable vor all skills of one team
         plnumbers1=plnumbers1+1       --count the number of players for the team                   
         table.insert(teamcn,plweight) --table for the player skills
      end    
   end
   return teamcn,wholeall1,plnumbers1
end

--[[ BESTMATCH
   returns the best matching player (his playercn) to switch if there is an unbalance in team count and all count
]]
function balance.bestMatch(team1,teampw1,diff,balcn)
local diffBetween = 0
local team = team1
local teampw = teampw1
local sorted = {}   
local match=diff/2    --divides diff by 2, and find the closest player
local playercn

   for key,all in pairs(teampw) do
      playercn = team[key]
      diffBetween = 0
      diffBetween=math.abs(all-match)   -- calculates the difference between playerweigt und diff/2
      table.insert(sorted,diffBetween)  --write the diffBetween in the new table to sort it
      messages.debug(cn, players.all(), "BALANCE","diffBetween for CN= "..tostring(playercn).." diffBetween= "..tostring(diffBetween))
      errorLog("diffBetween for CN= "..tostring(playercn).." diffBetween= "..tostring(diffBetween),"Bestmatch")
   end       

team,sorted = balance.sortPlayers(team,sorted) -- use sortPlayers to sort the new list
playercn = balance.findLowest(team,sorted,balcn)
if playercn == -1 then
   return -1
end
return playercn
end

--[[ FINDLOWEST
find the player with the lowest 'all', whichever have no flag and scored fewest
return the player's playercn
i = maximum on players
]]
function balance.findLowest(team1,teampw1,balcn1)
local team = {}
local teampw = {}
local balcn=balcn1
team = team1
teampw = teampw1

   i=0   --counter for the max players
   for key,tab in pairs(teampw) do
      i=i+1   
   end

   for j=0,5 do   -- if the player scored 5 times
   k=1      
      for key,tab in pairs(teampw) do    -- searched the team table to find a matching player
         playercn=team[key]  --takes the cn out of the team table
         player_id = server.player_sessionid(playercn)   
         tab = nl_players[player_id]
         -- test if the player currently hold the flag and do the minimum scores
         -- tab.flagholder ~= true and        
         if balcn ~= playercn or balcn ~= -1 then           
               if tab.flags_scored < j or k==i then 
               -- took the lowest player if they all have been switched before     
                     if tab.gotswitched then
                        if k == i then            
                           playercn=team[1] -- took the lowest player
                           errorLog("Playercn all got switched: "..tostring(playercn),"Findlowest")
                           return playercn
                        end
                     k=k+1      
                     else
                        errorLog("Playercn gotswitched not set: "..tostring(playercn),"Findlowest")
                        return playercn           
                     end
               end
         end
      end 
   end
   errorLog("No lowest player","Findlowest")
   return -1 --if there is no matched player found
end

--[[ CHANGETEAM
change the player which is given by the playercn
]]
function balance.changeTeam(balcn1)
local balcn = 0
local oteam = "good"
balcn = balcn1

   if balcn ~= -1 then 
   --set the gotswitched varriable          
      player_id = server.player_sessionid(balcn)
      nl_players[player_id].gotswitched = true
      
      oteam = balance.oppositeteam(balcn)
      
      player_id = server.player_sessionid(balcn)   
      tab = nl_players[player_id]
      -- test if the player currently hold the flag

      if tab.flagholder ~= true  then         
         -- wait 1sec before switching the player   
               server.sleep(1000, function()
               -- server.changeteam(balcn,oteam)
               -- server.msg(string.format("%s switched team for balance (autobalance)", nl.getPlayer(balcn, "name")))
               -- change Hanack 20-Nov-2010
               changeteam.changeteam(balcn,oteam,true)
               messages.info(-1, players.all(), "BALANCE", string.format("%s switched team for balance (autobalance)", nl.getPlayer(balcn, "name")))
               end)
         else
               messages.debug(cn, players.all(), "BALANCE","Player CN= "..tostring(balcn).."Player Holds the flag")
               errorLog("Player CN= "..tostring(balcn).."Player Holds the flag","Changeteam")
         end
      messages.debug(cn, players.all(), "BALANCE","Change Player CN= "..tostring(balcn))
      errorLog("Change Player CN= "..tostring(balcn),"Changeteam")
   else 
      errorLog("No change Team","Changeteam") 
      messages.debug(cn, players.all(), "BALANCE","No change Team")
end
end

--[[ NL.OPPOSITETEAM
find out the opposite team of the player given by the playercn
returns the opposite team
]]
function balance.oppositeteam(balcn1)
local balcn = 0
balcn = balcn1

   team = server.player_team(balcn)
   if team=="good" then
      team="evil"
   else
      team="good"
   end
   return team
end


--[[ SORTPLAYERS
sort the players from smallest to the greatest by there 'all' number.
]]
function balance.sortPlayers(team,teampw)
local team1 = {}
local teampw1 = {}
team1=team
teampw1=teampw

--sort tableset 1
   for key1,tab1 in pairs(teampw1) do
      for key2,tab2 in pairs(teampw1) do
         if tab1 > tab2 then
            change1=teampw1[key1]
            teampw1[key1]=teampw1[key2]
            teampw1[key2]=change1
            change1=team1[key1]
            team1[key1]=team1[key2]
            team1[key2]=change1
         end
      end
   end
return team1,teampw1
end

--[[
Playerweight function 
Calculates an number for each player to make the player skills matchable.

Choose the game mode and calculate depanding on the mode the playerweight.
possible game modes:
["ctf","insta ctf","efficiency ctf","efficiency hold","insta hold","efficienty protect",
"insta protect","protect","regen capture","capture"]

modes which are currently not available
["ffa","coop-edit","teamplay","instagib","inteagib team","efficiency","efficiency team","tactics","tactics team"]

Author: NuckChorris
Last Modified: 18/Nov/2010
Version: 0.02a

return value -1 if the the player doesn't exist.
return playerweight value.
]]

function balance.playerweight(playercn)
local cn = -1
--Gamemodes with only two teams:
            if maprotation.game_mode == "ctf" or maprotation.game_mode == "hold" or maprotation.game_mode == "protect" then
--CTF HOLD PROTECT
            local dpdw  = 1.0    --Damage per Damage wasted
            local spts  = 1.0    --scores per total scores of team
            local frpfs = 1.0    --flag reset by player per flag stolen by enemy team
            local spd   = 1.0    --suicides per deaths
            local all   = 1.0    --number for player

                player_id = server.player_sessionid(playercn)
                     if player_id == -1 or player_id==nil then
                           return -1
                     else 

                           local tab = nl_players[player_id]
                           local scores = tab.flags_scored
                           local flagreturned = tab.flags_returned
                           local totalScored = tab.total_scored
                           local flagsGone = tab.flags_gone
                           local damage = server.player_damage(playercn)
                           local damagewasted = server.player_damagewasted(playercn)
                           local suicides = player_suicides(cn)
                           local deaths = server.player_deaths(cn) 

                           -- calculate damage per damagewasted
                           if damage==0 or damage==nil then dpdw = 0 else
                              dpdw = damage/damagewasted
                           end
                           -- calculate scores to totalscores
                           if scores == 0 or scores==nil then spts = 0  else
                              spts = scores/totalScored   
                           end
                           -- calculate flagreturns of the player to flagsgone by wholeteam
                           if flagreturned == 0 or flagreturned==nil then frpfs = 0 else 
                              frpfs = flagreturned/flagsGone          
                           end
                           -- calculates suicides per deaths
                           if suicides == 0 or suicides==nil then spd = 0 else
                              spd = suicides/deaths
                           end

                           all = dpdw + spts + frpfs -spd -- calculate all variable
                           if all < 0 then all = 0 end -- in the case one player do only teamkills

messages.debug(cn, players.admins(),"BALANCE","playercn "..tostring(playercn).." all= "..tostring(all).." CTF,HOLD,PROTECT")
                        return all     
                  end

            elseif maprotation.game_mode == "insta ctf" or maprotation.game_mode == "insta hold"  or maprotation.game_mode == "insta protect" then
--INSTA CTF INSTA HOLD INSTA PROTECT
            local fps   = 1.0    --kills per hits
            local spts  = 1.0    --scores per total scores of team
            local frpfs = 1.0    --flag reset by player per flag stolen by enemy team
            local tkps  = 1.0    --teamkills per hits
            local all   = 1.0    --number for player

                player_id = server.player_sessionid(playercn)
                     if player_id == -1 or player_id==nil then
                           return -1
                     else 
                        
                           local tab = nl_players[player_id]
                           local frags = tab.frags
                           local shots = tab.shots
                           local scores = tab.flags_scored
                           local teamkills = tab.tk_made
                           local flagreturned = tab.flags_returned
                           local totalScored = tab.total_scored
                           local flagsGone = tab.flags_gone
                         
                           -- calculate the weighting number
                           if frags==0 or frags==nil then fps = 0 else
                              fps = frags/shots
                           end
                           -- calculate scores to totalscores
                           if scores == 0 or scores==nil then spts = 0  else
                              spts = scores/totalScored   
                           end
                           -- calculate flagreturns of the player to flagsgone by wholeteam
                           if flagreturned == 0 or flagreturned==nil then frpfs = 0 else 
                              frpfs = flagreturned/flagsGone          
                           end
                           -- calculates teamkills to shots
                           if teamkills == 0 or teamkills==nil then tkps =0 else
                              tkps = teamkills/shots
                           end

                           all = fps + spts + frpfs - tkps -- calculate all variable
                           if all < 0 then all = 0 end -- in the case one player do only teamkills
messages.debug(cn, players.admins(),"BALANCE","playercn "..tostring(playercn).." all= "..tostring(all).." INSTA")
                        return all     
                  end

            elseif maprotation.game_mode == "efficiency ctf" or maprotation.game_mode == "efficiency hold" or maprotation.game_mode == "efficienty protect" then
--EFFICIENCY CTF EFFICIENCY HOLD EFFICIENCY PROTECT
            local dpdw  = 1.0    --Damage per Damage wasted
            local spts  = 1.0    --scores per total scores of team
            local frpfs = 1.0    --flag reset by player per flag stolen by enemy team
            local spd   = 1.0    --suicides per deaths
            local all   = 1.0    --number for player

                player_id = server.player_sessionid(playercn)
                     if player_id == -1 or player_id==nil then
                           return -1
                     else 

                           local tab = nl_players[player_id]
                           local scores = tab.flags_scored
                           local flagreturned = tab.flags_returned
                           local totalScored = tab.total_scored
                           local flagsGone = tab.flags_gone
                           local damage = server.player_damage(playercn)
                           local damagewasted = server.player_damagewasted(playercn)
                           local suicides = player_suicides(cn)
                           local deaths = server.player_deaths(cn) 
                        
                           -- calculate damage per damagewasted
                           if damage==0 or damage==nil then dpdw = 0 else
                              dpdw = damage/damagewasted
                           end
                           -- calculate scores to totalscores
                           if scores == 0 or scores==nil then spts = 0  else
                              spts = scores/totalScored   
                           end
                           -- calculate flagreturns of the player to flagsgone by wholeteam
                           if flagreturned == 0 or flagreturned==nil then frpfs = 0 else 
                              frpfs = flagreturned/flagsGone          
                           end
                           -- calculates suicides per deaths
                           if suicides == 0 or suicides==nil then spd = 0 else
                              spd = suicides/deaths
                           end
                           all = dpdw + spts + frpfs - spd -- calculate all variable
                           if all < 0 then all = 0 end -- in the case one player do only teamkills                     
messages.debug(cn, players.admins(),"BALANCE","playercn "..tostring(playercn).." all= "..tostring(all).." EFFICIENCY")
                        return all     
                  end

--Gamemodes with more or equal than two teams
elseif   maprotation.game_mode == "regen capture"      then
   messages.debug(cn, players.admins(),"BALANCE","Playerweight REGEN CAPTURE processed")
elseif   maprotation.game_mode == "capture"            then
   messages.debug(cn, players.admins(),"BALANCE","Playerweight CAPTURE processed")
else
   messages.debug(cn, players.admins(),"BALANCE","Playerweight not processed")
   return 0
end

end

--[[
write an error log, with the given values
]]
function errorLog(errString,func)
file = io.open ("log/balance.log","a+")

--[[
			write in balance.log
]]
	if errString ~= nil and func ~= nil then
	   file:write(os.date("[%a %d %b %X] ",os.time()))
      file:write(func)
      file:write("  ")	  
      file:write(errString)
	   file:write("\n")
	   file:flush()
      file:close()
   end
end
--#################################################################################################

--[[
Balance toggle for the above balance skript

Derk Haendel
09-Oct-2010
License: GPL3
last-modified 19/Nov/2010
]]

function server.playercmd_balance(cn, arg1)--,playernumber1,playernumber2
	if not hasaccess(cn, balance_access) then return end
	
	   local err = false
	   local action = "i"

	   if arg1 then
		      if tostring(arg1) == "f" or tostring(arg1) == "force" then
               action = "f"
			   elseif tostring(arg1) == "t" or tostring(arg1) == "toggle" then
				   action = "t"
			   elseif tostring(arg1) == "i" or tostring(arg1) == "info" then
				   action = "i"
            elseif tostring(arg1) == "u" or tostring(arg1) == "unbalance" then
               action = "u"
			   else
			   err = true
		      end
	   end

	   if err then
		   server.player_msg(cn, string.format(red("Argument could only be: f or force or t or toggle or i or info")))
	   elseif action == "t" then
			   if server.nl_balance_enabled == 1 then
				   server.nl_balance_enabled = 0
				   server.player_msg(cn, string.format(red("Autobalance disabled")))
			   else
				   server.nl_balance_enabled = 1
				   server.player_msg(cn, string.format(red("Autobalance enabled")))
			   end
		end
	   if action == "f" then
			   server.player_msg(cn, string.format(red("Autobalance forced")))
			   nl.balance(cn)
	   end
	   if action == "i" then
			   if server.nl_balance_enabled == 1 then
				   server.player_msg(cn, string.format(red("INFO: Autobalance is enabled")))
			   else
				   server.player_msg(cn, string.format(red("INFO: Autobalance is disabled")))
			   end
	   end
end
server.playercmd_bal = server.playercmd_balance

function server.playercmd_nuck()
	if not hasaccess(cn, balance_access) then return end
	nl.balance()
end

--[[
Server-Events for the above balance skript

Derk Haendel
15-Oct-2010
License: GPL3

]]

server.event_handler("spectator", function(cn, val)
	if server.nl_balance_enabled == 1 and nl.getPlayer(cn, "switch") == true and val == 1 then
		nl.updatePlayer(cn, "switch", false, "set")
		nl.balance()
	end
end)
--  cn is the shooting player, targetcn is the death player
server.event_handler("frag", function(cn) nl.balance(cn) end)

-- commented by NuckChorris 15.11.2010
--server.event_handler("scoreflag", function(cn, team)
	--messages.info(cn, players.all(), "SCORE", string.format("server.nl_balance_enabled=%i", server.nl_balance_enabled))
	--if server.nl_balance_enabled == 1 then nl.balance()	end
--end)

server.interval(30000, function()
	--messages.info(cn, players.all(), "SCORE", string.format("server.nl_balance_enabled=%i", server.nl_balance_enabled))
	if server.nl_balance_enabled == 1 then nl_game.do_balance = true end
end)

