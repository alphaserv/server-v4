--[[
	script/module/nl_mod/nl_cheater.lua
	Hanack (Andreas Schaeffer)
	Created: 24-Okt-2010
	Last Modified: 24-Okt-2010
	License: GPL3

	Funktionen:
		Bannen von Speedhackern, Maphackern und Teamkillern
		Erkennen von MapHackern mit Teleportern an jeder Flag (FastScores)
		Erkennen und Verhindern von Rename-Flood.
		Erkennen von bereits vorhandenen IPs

	Commands:
		#xban
			xyz
		#protect
			xyz
		#disapear <CN>
			Den Spieler mit der CN verschwinden lassen
		#follow
			Dem aktuellen Cheater folgen
		#kickhim
			Den aktuellen Cheater bannen

	API-Methoden:
		cheater.xyz()
			xyz

	Konfigurations-Variablen:
		cheater.xyz
			xyz
]]



--[[
		API
]]

cheater = {}
cheater.ban = {}
cheater.ban.time = 3600
cheater.ban.delay = 30000
cheater.ban.reasons = {
	tk = "teamkilling",
	mh = "maphacking",
	sh = "speedhacking"
}
cheater.ban.subject = {
	tk = "teamkiller",
	mh = "maphacker",
	sh = "speedhacker"
}
cheater.fastscores = {}
cheater.fastscores.minflagrunmills = 3000
cheater.fastscores.good = {}
cheater.fastscores.good.dropped = 0
cheater.fastscores.good.takeflagmillis = 0
cheater.fastscores.evil = {}
cheater.fastscores.evil.dropped = 0
cheater.fastscores.evil.takeflagmillis = 0
cheater.rename = {}
cheater.rename.warnings = 4
cheater.rename.ban = 12
cheater.stottern = {}
cheater.stottern.delay = { 60, 15 }
cheater.follow_cheater_cn = nil

function cheater.stottern(cn)
	if nl.getPlayer(cn, "stottern") == 1 then
		nl.updatePlayer(cn, "stottern", 2, "set")
		server.sleep(cheater.stottern.delay[1], function()
			server.player_freeze(cn)
			cheater.stottern(cn)
		end)
	elseif nl.getPlayer(cn, "stottern") == 2 then
		nl.updatePlayer(cn, "stottern", 1, "set")
		server.sleep(cheater.stottern.delay[2], function()
			server.player_unfreeze(cn)
			cheater.stottern(cn)
		end)
	end
end

function cheater.reset_repression(cn)
	nl.updatePlayer(cn, "repression", 0, "set")
	nl.updatePlayer(cn, "stottern", 0, "set")
	nl.updatePlayer(cn, "antirespawn", 0, "set")
	nl.updatePlayer(cn, "antifragging", 0, "set")
	nl.updatePlayer(cn, "protect", 0, "set")
	nl.updatePlayer(cn, "rename", 0, "set")
end

function cheater.check_same_ip(cn)
	for _, player_cn in ipairs(players.all()) do
		if cn ~= player_cn and server.player_ip(cn) == server.player_ip(player_cn) then
			messages.warning(cn, players.admins(), "CHEATER", string.format("%s (%i) has same ip as %s (%i). Please check this! Demofile: %s", server.player_name(cn), cn, server.player_name(player_cn), player_cn, server.stats_demo_filename))
		end
	end
end

function cheater.set_follow_cheater(cn, reason)
	cheater.follow_cheater_cn = cn
	cheater.follow_cheater_reason = reason
end



--[[
		COMMANDS
]]

function server.playercmd_follow(cn)
	messages.warning(cn, {cn}, "CHEATER", "#follow is not fully implemented")
	server.spec(cn)
end

function server.playercmd_kickhim(cn)
	messages.error(cn, players.admins(), "CHEATER", server.player_displayname(cheater.follow_cheater_cn) .. " was kicked because of " .. cheater.follow_cheater_reason)
	server.kick(cheater.follow_cheater_cn, cheater.ban.time, server.player_displayname(cn), cheater.follow_cheater_reason)
end

function server.playercmd_xban(cn, targetCN, reason, _bandelay)
	if not hasaccess(cn, xban_access) then return end
	cn = tonumber(cn)
	targetCN = tonumber(targetCN)
	if not targetCN or not reason then
		return false, "#xban <cn> <reason> [<seconds>]"
	end
	local bandelay = cheater.ban.delay
	if _bandelay then bandelay = _bandelay*1000 end
	if reason == "undo" then
		cheater.reset_repression(targetCN)
		server.sleep(200, function()
			server.player_unfreeze(targetCN)
		end)
	else
		nl.updatePlayer(cn, "repression", 1, "set")
		if reason == "sh" then
			nl.updatePlayer(cn, "stottern", 1, "set")
			cheater.stottern(targetCN)
		elseif reason == "mh" then
			nl.updatePlayer(cn, "antirespawn", 1, "set")
		elseif reason == "tk" then
			nl.updatePlayer(cn, "antifragging", 1, "set")
		end
		server.sleep(bandelay, function()
			if nl.getPlayer(cn, "repression") == 1 then
				server.kick(targetCN, cheater.ban.time, server.player_displayname(cn), cheater.ban.reasons[reason])
			end
		end)
		messages.warning(cn, players.except(players.all(), targetCN), "CHEATER", server.player_displayname(targetCN) .. "is a " .. cheater.ban.subject[reason] .. ". Say bye bye!")
	end
end

function server.playercmd_protect(cn, targetCN, protect)
	if not hasaccess(cn, protect_access) then return end
	if protect ~= nil then
		nl.updatePlayer(cn, "protect", value, "set")
	else
		nl.updatePlayer(cn, "protect", 1, "set")
	end
end

function server.playercmd_disapear(cn, targetCN)
	if not hasaccess(cn, disapear_access) then return end
	server.disconnect(targetCN, server.DISC_TAGT, "")
end



--[[
		EVENTS
]]

server.event_handler("damage", function(targetCN, actorCN, damage, gun)
	if nl.getPlayer(cn, "antifragging") == 1 then
		server.player_suicide(actorCN)
		return -1
	end
	if nl.getPlayer(cn, "protect") == 1 then
		server.player_slay(actorCN)
		return -1
	end
end)

server.event_handler("spawn", function(cn)
	if nl.getPlayer(cn, "antirespawn") == 1 then
		server.player_slay(cn)
	end
end)

server.event_handler("connect", function(cn)
	cheater.reset_repression(cn)
	cheater.check_same_ip(cn)
end)

server.event_handler("disconnect", function(cn)
	cheater.reset_repression(cn)
	if cheater.follow_cheater_cn ~= nil and cn == cheater.follow_cheater_cn then
		cheater.follow_cheater_cn = nil
	end
end)

server.event_handler("scoreflag", function(cn)
	if server.player_team(cn) == "good" then
		if cheater.fastscores.good.takeflagmillis == nil then
			cheater.fastscores.good.takeflagmillis = 0
		end
		local flagrunmillis = server.gamemillis - cheater.fastscores.good.takeflagmillis
		messages.debug(cn, players.admins(), "CHEATER", "Flagrun took "..flagrunmillis.." ms")
		if flagrunmillis < cheater.fastscores.minflagrunmills and cheater.fastscores.good.dropped == 0 then
			-- server.kick(cn, cheater.ban.time, "Server", "maphacking")
			messages.error(cn, players.admins(), "CHEATER", server.player_name(cn) .. " (" .. cn .. ") was kicked because of maphacking (flagrun took " .. flagrunmillis .. " ms)! Demofile: " .. server.stats_demo_filename)
		end
		cheater.fastscores.good.dropped = 0
	elseif server.player_team(cn) == "evil" then
		if cheater.fastscores.evil.takeflagmillis == nil then
			cheater.fastscores.evil.takeflagmillis = 0
		end
		local flagrunmillis = server.gamemillis - cheater.fastscores.evil.takeflagmillis
		messages.debug(cn, players.admins(), "CHEATER", "Flagrun took "..flagrunmillis.." ms")
		if flagrunmillis < cheater.fastscores.minflagrunmills and cheater.fastscores.evil.dropped == 0 then
			-- server.kick(cn, cheater.ban.time, "Server", "maphacking")
			messages.error(cn, players.admins(), "CHEATER", server.player_name(cn) .. " (" .. cn .. ") was kicked because of maphacking (flagrun took " .. flagrunmillis .. " ms)! Demofile: " .. server.stats_demo_filename)
		end
		cheater.fastscores.evil.dropped = 0
	end

end)

server.event_handler("takeflag", function(cn)
	if server.player_team(cn) == "good" then
		cheater.fastscores.good.takeflagmillis = server.gamemillis
	elseif server.player_team(cn) == "evil" then
		cheater.fastscores.evil.takeflagmillis = server.gamemillis
	end
end)

server.event_handler("dropflag", function(cn)
	if server.player_team(cn) == "good" then
		cheater.fastscores.good.dropped = 1
	elseif server.player_team(cn) == "evil" then
		cheater.fastscores.evil.dropped = 1
	end
end)

server.event_handler("resetflag", function(cn)
	-- TODO: was machen, wenn keine gueltige CN uebergeben wird???
	if cn == nil then
		cheater.fastscores.good.dropped = 0
		cheater.fastscores.evil.dropped = 0
	elseif utils.is_numeric(cn) then
		if server.player_team(tonumber(cn)) == "good" then
			cheater.fastscores.good.dropped = 0
		elseif server.player_team(tonumber(cn)) == "evil" then
			cheater.fastscores.evil.dropped = 0
		end
	else
		cheater.fastscores.good.dropped = 0
		cheater.fastscores.evil.dropped = 0
	end
end)

server.event_handler("mapchange", function()
	cheater.fastscores.good.dropped = 0
	cheater.fastscores.evil.dropped = 0
end)

server.event_handler("allow_rename", function(cn, text)
	nl.updatePlayer(cn, "rename", 1, "add")
	if nl.getPlayer(cn, "rename") >= cheater.rename.ban then
		server.kick(cn, cheater.ban.time, "Server", "rename flooding")
		messages.error(cn, players.admins(), "RENAME FLOOD", server.player_name(cn) .. " (" .. cn .. ") was kicked because of rename flooding! Demofile: " .. server.stats_demo_filename)
		return -1
	end
	if nl.getPlayer(cn, "rename") >= cheater.rename.warnings then
		messages.warning(cn, cn, "RENAME FLOOD", "You are not allowed to rename too often!")
		return -1
	end
end)

