auth.directory.domain{
    id = "pro:admin",
    server = "LOCAL"
}

auth.directory.user{
    domain = "pro:admin",
    id = "X35",
    public_key = "-16b3f118920c5b004817fbfebedf560c309e59918c89aaee"
}