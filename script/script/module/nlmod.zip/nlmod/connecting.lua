local c1 = server.color_1
local c2 = server.color_2

local nounabletoconnectmsg = {}
local disappeared = {}

function server.nounabletoconnectmsg(ip)
	nounabletoconnectmsg[ip] = true
end

function server.disappeared(ip, reason)
	disappeared[ip] = reason
end

if not server.realmaxclients then server.realmaxclients = server.maxclients end
if not server.maxplayers then server.maxplayers = server.maxclients end
if not server.xstatsmaxclients then server.xstatsmaxclients = server.maxclients end

server.event_handler("connecting", function(cn, ip, name, pwd, banned)
	auth.initclienttable(cn)
	server.set_access(cn, 0)
	nl.createPlayer(cn)
	if string.len(tostring(pwd)) > 0 then
		nl.updatePlayer(cn, "slotpass", pwd, "set")
  end
	nl.check_player_status(cn, pwd, "sauer")
	if is_invited(cn, name, ip, pwd) then
		server.sleep(10, function() server.msg(getmsg("{1} has been invited", name)) end)
		if xbotlog then xbotlog(xbotmark(name) .. " has been invited") end
		return server.DISC_NONE
	elseif checkban(ip, name) then -- permanent ban
		log(name .. " (" .. ip .. ") unabled to connect because permanently banned.")
		if not nounabletoconnectmsg[ip] then
			server.msg(getmsg("player {1} could not connect ({2})", name, "permanently banned"))
			if xbotlog then xbotlog("player " .. xbotmark(name) .. " could not connect (permanently banned)") end
		end
		return server.DISC_IPBAN
	elseif server.checkban(ip) then -- temporary ban
		if not nounabletoconnectmsg[ip] then
			server.msg(getmsg("player {1} could not connect ({2})", name, "temporarily banned"))
			if xbotlog then xbotlog("player " .. xbotmark(name) .. " could not connect (temporarily banned)") end
		end
		if disappeared[ip] then
			return disappeared[ip]
		else
			return server.DISC_IPBAN
		end
	elseif nl.getPlayer(cn, "nl_status") == "user" or nl.getPlayer(cn, "nl_status") == "admin" then
		return server.DISC_NONE
	elseif pwd == server.hashpassword(cn, "auth") and server.playercount < 128 then
		server.authconnecting(cn)
		server.send_connect_auth(cn)
		return server.DISC_NONE
	elseif server.playercount >= server.maxclients or server.playercount >= server.realmaxclients then
		if server.xstats_check_connection and (server.playercount - server.speccount) < server.xstatsmaxclients and server.playercount < server.realmaxclients then
			server.authconnecting(cn)
			server.xstats_check_connection(cn, function(cn, user, authkey, access)
				server.xstats_playerlogin(cn, user, authkey, access)
				server.finishconnect(cn)
				if server.player_status(cn) ~= "spectator" then server.spawn_player(cn) end
			end, function(cn)
				local sid = server.player_sessionid(cn)
				server.player_msg(cn, badmsg("you have no permission to use this name on this server, please change your name in order to be able to connect!"))
				server.sleep(100, function() if sid == server.player_sessionid(cn) then server.disconnect(cn, 0, "") end end)
			end, function(cn)
				local sid = server.player_sessionid(cn)
				server.resetpvars(cn)
				server.player_msg(cn, getmsg("get a free slot and mind being unable to connect on a full server in the future by registering at {1} > {2}!", "http://is.kicks-ass.org/", "xstats registration"))
				server.sleep(100, function()
					if sid == server.player_sessionid(cn) then
						server.nodiscmsg(cn)
						server.disconnect(cn, server.DISC_MAXCLIENTS, "")
						if not nounabletoconnectmsg[ip] then
							server.msg(getmsg("player {1} could not connect ({2})", name, "server full"))
							if xbotlog then xbotlog("player " .. xbotmark(name) .. " could not connect (server full)") end
						end
					end
				end)
			end)
			return server.DISC_NONE
		else
			if not nounabletoconnectmsg[ip] then
				server.msg(getmsg("player {1} could not connect ({2})", name, "server full"))
				if xbotlog then xbotlog("player " .. xbotmark(name) .. " could not connect (server full)") end
			end
			return server.DISC_MAXCLIENTS
		end
	elseif server.mastermode == 3 then
		if not nounabletoconnectmsg[ip] then
			server.msg(getmsg("player {1} could not connect ({2})", name, "server private"))
			if xbotlog then xbotlog("player " .. xbotmark(name) .. " could not connect (server private)") end
		end
		return server.DISC_PRIVATE
	else
		if server.xstats_check_connection then
			server.authconnecting(cn)
			server.xstats_check_connection(cn, function(cn, user, authkey, access)
				server.xstats_playerlogin(cn, user, authkey, access)
				server.finishconnect(cn)
				if server.player_status(cn) ~= "spectator" then server.spawn_player(cn) end
			end, function(cn)
				local sid = server.player_sessionid(cn)
				server.player_msg(cn, badmsg("you have no permission to use this name on this server, please change your name in order to be able to connect!"))
				server.sleep(100, function() if sid == server.player_sessionid(cn) then server.disconnect(cn, 0, "") end end)
			end, function(cn)
				server.resetpvars(cn)
				server.finishconnect(cn)
				if server.player_status(cn) ~= "spectator" then server.spawn_player(cn) end
			end)
		end
		return server.DISC_NONE
	end
end)

server.event_handler("setmastermode", function(cn, old, newname)
	if newname == "private" then new = 3
	elseif newname == "locked" then new = 2
	elseif newname == "veto" then new = 1
	else new = 0 end
	server.mastermode = new
end)

server.event_handler("connect", function(cn)
	server.maxclients = server.maxplayers + server.speccount
	if server.maxclients > server.realmaxclients then server.maxclients = server.realmaxclients end
	nounabletoconnectmsg[server.player_ip(cn)] = nil
	server.unban(server.player_ip(cn))
	disappeared[server.player_ip(cn)] = nil
end)

server.event_handler("disconnect", function(cn)
	server.maxclients = server.maxplayers + server.speccount
	if server.maxclients > server.realmaxclients then server.maxclients = server.realmaxclients end
end)

server.event_handler("spectator", function(cn, val)
	server.maxclients = server.maxplayers + server.speccount
	if server.maxclients > server.realmaxclients then server.maxclients = server.realmaxclients end
end)

server.event_handler("kick", function(cn, rtime, admin_cn, rreason)
	local admin
	local admin_
	local reason
	local reason_
	local authedname
	local authedname_
	if admin_cn and admin_cn ~= -1 then
		if server.valid_cn(admin_cn) then
			admin_ = " by {4}"
			admin = server.player_displayname(admin_cn)
			authedname = server.authedname(admin_cn)
			if authedname then
				authedname_ = " (authed as {6})"
			else
				authedname_ = ""
			end
		else
			admin_ = ""
			admin = -1
			reason = ""
			reason_ = ""
			authedname = ""
			authedname_ = ""
		end
	else
		admin_ = ""
		admin = -1
		reason = ""
		reason_ = ""
		authedname = ""
		authedname_ = ""
	end
	if rreason and rreason ~= "" then
		reason_ = " ({5})"
		reason = rreason
	else
		reason_ = ""
		reason = ""
	end
	if rtime > 0 then
		time = round(rtime / 60)
		if time < 60 then
			msg = getmsg("player {1} was kicked and banned" .. admin_ .. authedname_ .. " for {2} minutes" .. reason_, server.player_displayname(cn), time, nil, admin, reason, authedname)
		else
			time = (rtime / 3600)
			hours, minutes = string.match(tostring(time), "(%S+)[.](%S+)")
			if not hours or not minutes then hours = time; minutes = 0 end
			if hours > 1 then hours_ = "hours"
			else hours_ = "hour" end
			if tonumber(minutes) == 0 then
				msg = getmsg("player {1} was kicked and banned" .. admin_ .. authedname_ .. " for {2} " .. hours_ .. reason_, server.player_displayname(cn), hours, nil, admin, reason, authedname)
			else
				msg = getmsg("player {1} was kicked and banned" .. admin_ .. authedname_ .. " for {2} " .. hours_ .. " and {3} minutes" .. reason_, server.player_displayname(cn), hours, minutes, admin, reason, authedname)
			end
		end
	else
		msg = getmsg("player {1} was kicked" .. admin_ .. authedname_ .. reason_, server.player_displayname(cn), nil, nil, admin, reason, authedname)
	end
	server.sleep(10, function() server.msg(msg) end)
end)

local nomsg = {}

function server.nodiscmsg(cn)
	nomsg[cn] = true
end

server.event_handler("disconnect", function(cn, reason)
	if reason ~= "normal" and reason ~= "kicked/banned" and reason ~= "" then
		if not nomsg[cn] then
			msg = getmsg("{1} disconnected because {2}", server.player_displayname(cn), reason)
			server.sleep(100, function() server.msg(msg) end)
		else
			nomsg[cn] = nil
		end
	end
end)
