--[[


PROTOTYP !!!
MEHR NICHT


	script/module/nl_mod/nl_reconnect.lua
	Hanack (Andreas Schaeffer)
	23-Okt-2010
	License: GPL3

	Funktion:
		Ein Spieler verbindet sich innerhalb von 10 Minuten neu. Dann wird ein
		Event namens reconnect ausgelöst

]]	



--[[
		API
]]

reconnect = {}
reconnect.signal = server.create_event_signal("reconnect")
reconnect.delay=2
reconnect.offtime=2



--[[
		COMMANDS
]]

function server.playercmd_reconnect(cn, command, arg)
	if not hasaccess(cn, admin_access) then return end
	if command == nil then
		return false, "#reconnect <CMD> [<ARG>]"
	else
		if arg == nil then
			if command == "lastconnects" then
				return false, "#reconnect lastconnects <CN>"
			end
			if command == "info" then
				messages.info(cn, {cn}, "RECONNECT", "reconnect.delay=%s"..reconnect.delay)
				messages.info(cn, {cn}, "RECONNECT", "reconnect.offtime=%s"..reconnect.offtime)
			end
		else
			if command == "lastconnects" then
				local connects = db.select("nl_reconnect", {"ts", "name"}, string.format( "ip='%s' OR name='%s' OR id='%s' ORDER BY ts DESC LIMIT 5", server.player_ip(arg), server.player_name(arg), server.player_id(arg) ))
				messages.info(cn, {cn}, "RECONNECT", "List of the last 5 connects: ")
				for i,connect in pairs(connects) do
					messages.info(cn, {cn}, "RECONNECT", "  at "..connect.ts.." by "..connect.name)
				end
			end
			if command == "delay" then
				reconnect.delay = arg
				messages.info(cn, {cn}, "RECONNECT", "reconnect.delay="..reconnect.delay)
			end
			if command == "offtime" then
				reconnect.offtime = arg
				messages.info(cn, {cn}, "RECONNECT", "reconnect.offtime="..reconnect.offtime)
			end
		end
	end
end


--[[
		EVENTS
]]

server.event_handler("disconnect", function(cn)
	db.insert("nl_reconnect", { ip=server.player_ip(cn), name=server.player_name(cn), playerid=server.player_id(cn) } )
end)

server.event_handler("connect", function(cn)
	local connects = db.select("nl_reconnect", { "ip", "name", "playerid", "ts" }, string.format( "(ip='%s' OR name='%s' OR id='%s') AND ts >= DATE_SUB( NOW(), INTERVAL %i MINUTE )", server.player_ip(cn), server.player_name(cn), server.player_id(cn), reconnect.offtime ) )
	if #connects > 0 then
		local noconnects = #connects
		messages.info(cn, players.admins(), "RECONNECT", server.player_name(cn).." has reconnected ("..noconnects.." times within "..reconnect.offtime.." minutes)")
		for i,connect in pairs(connects) do
			messages.debug(cn, players.admins(), "RECONNECT", "  at "..connect.ts.." by "..connect.name)
		end
		reconnect.signal(cn, connects)
		server.sleep(reconnect.delay*1000, function()
			messages.warning(cn, {cn}, "RECONNECT", "You have reconnected or you use the same IP as someone else lately!")
			messages.warning(cn, {cn}, "RECONNECT", "To prevent misusage you cannot use some functions till intermission!")
		end)
	end
end)
