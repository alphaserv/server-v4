access_list["X35"] = 500
-- uncomment and edit the following line to give another user access! (500 = owner / 400 = admin / 200 = master / 0 = player)
-- access_list["user"] = 400
